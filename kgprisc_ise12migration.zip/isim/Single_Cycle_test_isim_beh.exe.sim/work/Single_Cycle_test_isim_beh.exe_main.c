/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

#include "xsi.h"

struct XSI_INFO xsi_info;



int main(int argc, char **argv)
{
    xsi_init_design(argc, argv);
    xsi_register_info(&xsi_info);

    xsi_register_min_prec_unit(-12);
    xilinxcorelib_ver_m_00000000001184809869_4133888041_init();
    xilinxcorelib_ver_m_00000000001184809869_3951028267_init();
    xilinxcorelib_ver_m_00000000001036818086_4224681051_init();
    xilinxcorelib_ver_m_00000000003636842937_1292328627_init();
    xilinxcorelib_ver_m_00000000002216354146_2937455867_init();
    work_m_00000000001848943485_3387524553_init();
    work_m_00000000001882300331_0011461451_init();
    work_m_00000000002430193526_3866583278_init();
    work_m_00000000003336752369_4122600708_init();
    work_m_00000000000534795708_3190593924_init();
    work_m_00000000001971807220_0833183191_init();
    work_m_00000000000605196592_0837587798_init();
    work_m_00000000001597691542_2725559894_init();
    work_m_00000000000716657888_2971651789_init();
    work_m_00000000003232003740_2251149424_init();
    work_m_00000000002336908629_3294457933_init();
    work_m_00000000002013452923_2073120511_init();


    xsi_register_tops("work_m_00000000002336908629_3294457933");
    xsi_register_tops("work_m_00000000002013452923_2073120511");


    return xsi_run_simulation(argc, argv);

}
