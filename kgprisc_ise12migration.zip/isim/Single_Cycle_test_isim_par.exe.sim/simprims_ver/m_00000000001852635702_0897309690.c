/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x12940baa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif




extern void simprims_ver_m_00000000001852635702_0897309690_3341297451_init()
{
	xsi_register_didat("simprims_ver_m_00000000001852635702_0897309690_3341297451", "isim/Single_Cycle_test_isim_par.exe.sim/simprims_ver/m_00000000001852635702_0897309690_3341297451.didat");
}

extern void simprims_ver_m_00000000001852635702_0897309690_3976163892_init()
{
	xsi_register_didat("simprims_ver_m_00000000001852635702_0897309690_3976163892", "isim/Single_Cycle_test_isim_par.exe.sim/simprims_ver/m_00000000001852635702_0897309690_3976163892.didat");
}

extern void simprims_ver_m_00000000001852635702_0897309690_1256074353_init()
{
	xsi_register_didat("simprims_ver_m_00000000001852635702_0897309690_1256074353", "isim/Single_Cycle_test_isim_par.exe.sim/simprims_ver/m_00000000001852635702_0897309690_1256074353.didat");
}

extern void simprims_ver_m_00000000001852635702_0897309690_2030356549_init()
{
	xsi_register_didat("simprims_ver_m_00000000001852635702_0897309690_2030356549", "isim/Single_Cycle_test_isim_par.exe.sim/simprims_ver/m_00000000001852635702_0897309690_2030356549.didat");
}

extern void simprims_ver_m_00000000001852635702_0897309690_3897763459_init()
{
	xsi_register_didat("simprims_ver_m_00000000001852635702_0897309690_3897763459", "isim/Single_Cycle_test_isim_par.exe.sim/simprims_ver/m_00000000001852635702_0897309690_3897763459.didat");
}

extern void simprims_ver_m_00000000001852635702_0897309690_1737784444_init()
{
	xsi_register_didat("simprims_ver_m_00000000001852635702_0897309690_1737784444", "isim/Single_Cycle_test_isim_par.exe.sim/simprims_ver/m_00000000001852635702_0897309690_1737784444.didat");
}

extern void simprims_ver_m_00000000001852635702_0897309690_1336257219_init()
{
	xsi_register_didat("simprims_ver_m_00000000001852635702_0897309690_1336257219", "isim/Single_Cycle_test_isim_par.exe.sim/simprims_ver/m_00000000001852635702_0897309690_1336257219.didat");
}

extern void simprims_ver_m_00000000001852635702_0897309690_1362435834_init()
{
	xsi_register_didat("simprims_ver_m_00000000001852635702_0897309690_1362435834", "isim/Single_Cycle_test_isim_par.exe.sim/simprims_ver/m_00000000001852635702_0897309690_1362435834.didat");
}

extern void simprims_ver_m_00000000001852635702_0897309690_2809434720_init()
{
	xsi_register_didat("simprims_ver_m_00000000001852635702_0897309690_2809434720", "isim/Single_Cycle_test_isim_par.exe.sim/simprims_ver/m_00000000001852635702_0897309690_2809434720.didat");
}
