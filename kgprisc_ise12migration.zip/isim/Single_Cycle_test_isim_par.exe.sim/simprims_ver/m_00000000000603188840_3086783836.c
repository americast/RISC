/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x12940baa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif



static void Gate_29_0(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;

LAB0:    t1 = (t0 + 2504U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = (t0 + 1344U);
    t3 = *((char **)t2);
    t2 = (t0 + 2904);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    xsi_vlog_notGate(t7, t3);
    t8 = (t0 + 2904);
    xsi_driver_vfirst_trans(t8, 0, 0);
    t9 = (t0 + 2824);
    *((int *)t9) = 1;

LAB1:    return;
}


extern void simprims_ver_m_00000000000603188840_3086783836_init()
{
	static char *pe[] = {(void *)Gate_29_0};
	xsi_register_didat("simprims_ver_m_00000000000603188840_3086783836", "isim/Single_Cycle_test_isim_par.exe.sim/simprims_ver/m_00000000000603188840_3086783836.didat");
	xsi_register_executes(pe);
}

extern void simprims_ver_m_00000000000603188840_3057581931_init()
{
	static char *pe[] = {(void *)Gate_29_0};
	xsi_register_didat("simprims_ver_m_00000000000603188840_3057581931", "isim/Single_Cycle_test_isim_par.exe.sim/simprims_ver/m_00000000000603188840_3057581931.didat");
	xsi_register_executes(pe);
}

extern void simprims_ver_m_00000000000603188840_3226763193_init()
{
	static char *pe[] = {(void *)Gate_29_0};
	xsi_register_didat("simprims_ver_m_00000000000603188840_3226763193", "isim/Single_Cycle_test_isim_par.exe.sim/simprims_ver/m_00000000000603188840_3226763193.didat");
	xsi_register_executes(pe);
}

extern void simprims_ver_m_00000000000603188840_2417123832_init()
{
	static char *pe[] = {(void *)Gate_29_0};
	xsi_register_didat("simprims_ver_m_00000000000603188840_2417123832", "isim/Single_Cycle_test_isim_par.exe.sim/simprims_ver/m_00000000000603188840_2417123832.didat");
	xsi_register_executes(pe);
}

extern void simprims_ver_m_00000000000603188840_2837618477_init()
{
	static char *pe[] = {(void *)Gate_29_0};
	xsi_register_didat("simprims_ver_m_00000000000603188840_2837618477", "isim/Single_Cycle_test_isim_par.exe.sim/simprims_ver/m_00000000000603188840_2837618477.didat");
	xsi_register_executes(pe);
}

extern void simprims_ver_m_00000000000603188840_1702356052_init()
{
	static char *pe[] = {(void *)Gate_29_0};
	xsi_register_didat("simprims_ver_m_00000000000603188840_1702356052", "isim/Single_Cycle_test_isim_par.exe.sim/simprims_ver/m_00000000000603188840_1702356052.didat");
	xsi_register_executes(pe);
}

extern void simprims_ver_m_00000000000603188840_2856569677_init()
{
	static char *pe[] = {(void *)Gate_29_0};
	xsi_register_didat("simprims_ver_m_00000000000603188840_2856569677", "isim/Single_Cycle_test_isim_par.exe.sim/simprims_ver/m_00000000000603188840_2856569677.didat");
	xsi_register_executes(pe);
}

extern void simprims_ver_m_00000000000603188840_2863024963_init()
{
	static char *pe[] = {(void *)Gate_29_0};
	xsi_register_didat("simprims_ver_m_00000000000603188840_2863024963", "isim/Single_Cycle_test_isim_par.exe.sim/simprims_ver/m_00000000000603188840_2863024963.didat");
	xsi_register_executes(pe);
}

extern void simprims_ver_m_00000000000603188840_2464846954_init()
{
	static char *pe[] = {(void *)Gate_29_0};
	xsi_register_didat("simprims_ver_m_00000000000603188840_2464846954", "isim/Single_Cycle_test_isim_par.exe.sim/simprims_ver/m_00000000000603188840_2464846954.didat");
	xsi_register_executes(pe);
}

extern void simprims_ver_m_00000000000603188840_1629427944_init()
{
	static char *pe[] = {(void *)Gate_29_0};
	xsi_register_didat("simprims_ver_m_00000000000603188840_1629427944", "isim/Single_Cycle_test_isim_par.exe.sim/simprims_ver/m_00000000000603188840_1629427944.didat");
	xsi_register_executes(pe);
}

extern void simprims_ver_m_00000000000603188840_1731287565_init()
{
	static char *pe[] = {(void *)Gate_29_0};
	xsi_register_didat("simprims_ver_m_00000000000603188840_1731287565", "isim/Single_Cycle_test_isim_par.exe.sim/simprims_ver/m_00000000000603188840_1731287565.didat");
	xsi_register_executes(pe);
}

extern void simprims_ver_m_00000000000603188840_0697872230_init()
{
	static char *pe[] = {(void *)Gate_29_0};
	xsi_register_didat("simprims_ver_m_00000000000603188840_0697872230", "isim/Single_Cycle_test_isim_par.exe.sim/simprims_ver/m_00000000000603188840_0697872230.didat");
	xsi_register_executes(pe);
}

extern void simprims_ver_m_00000000000603188840_1789321179_init()
{
	static char *pe[] = {(void *)Gate_29_0};
	xsi_register_didat("simprims_ver_m_00000000000603188840_1789321179", "isim/Single_Cycle_test_isim_par.exe.sim/simprims_ver/m_00000000000603188840_1789321179.didat");
	xsi_register_executes(pe);
}

extern void simprims_ver_m_00000000000603188840_1542519190_init()
{
	static char *pe[] = {(void *)Gate_29_0};
	xsi_register_didat("simprims_ver_m_00000000000603188840_1542519190", "isim/Single_Cycle_test_isim_par.exe.sim/simprims_ver/m_00000000000603188840_1542519190.didat");
	xsi_register_executes(pe);
}

extern void simprims_ver_m_00000000000603188840_1159374480_init()
{
	static char *pe[] = {(void *)Gate_29_0};
	xsi_register_didat("simprims_ver_m_00000000000603188840_1159374480", "isim/Single_Cycle_test_isim_par.exe.sim/simprims_ver/m_00000000000603188840_1159374480.didat");
	xsi_register_executes(pe);
}

extern void simprims_ver_m_00000000000603188840_3808827124_init()
{
	static char *pe[] = {(void *)Gate_29_0};
	xsi_register_didat("simprims_ver_m_00000000000603188840_3808827124", "isim/Single_Cycle_test_isim_par.exe.sim/simprims_ver/m_00000000000603188840_3808827124.didat");
	xsi_register_executes(pe);
}

extern void simprims_ver_m_00000000000603188840_1727213626_init()
{
	static char *pe[] = {(void *)Gate_29_0};
	xsi_register_didat("simprims_ver_m_00000000000603188840_1727213626", "isim/Single_Cycle_test_isim_par.exe.sim/simprims_ver/m_00000000000603188840_1727213626.didat");
	xsi_register_executes(pe);
}

extern void simprims_ver_m_00000000000603188840_1673275071_init()
{
	static char *pe[] = {(void *)Gate_29_0};
	xsi_register_didat("simprims_ver_m_00000000000603188840_1673275071", "isim/Single_Cycle_test_isim_par.exe.sim/simprims_ver/m_00000000000603188840_1673275071.didat");
	xsi_register_executes(pe);
}

extern void simprims_ver_m_00000000000603188840_3804527811_init()
{
	static char *pe[] = {(void *)Gate_29_0};
	xsi_register_didat("simprims_ver_m_00000000000603188840_3804527811", "isim/Single_Cycle_test_isim_par.exe.sim/simprims_ver/m_00000000000603188840_3804527811.didat");
	xsi_register_executes(pe);
}

extern void simprims_ver_m_00000000000603188840_3027779890_init()
{
	static char *pe[] = {(void *)Gate_29_0};
	xsi_register_didat("simprims_ver_m_00000000000603188840_3027779890", "isim/Single_Cycle_test_isim_par.exe.sim/simprims_ver/m_00000000000603188840_3027779890.didat");
	xsi_register_executes(pe);
}

extern void simprims_ver_m_00000000000603188840_1534463374_init()
{
	static char *pe[] = {(void *)Gate_29_0};
	xsi_register_didat("simprims_ver_m_00000000000603188840_1534463374", "isim/Single_Cycle_test_isim_par.exe.sim/simprims_ver/m_00000000000603188840_1534463374.didat");
	xsi_register_executes(pe);
}

extern void simprims_ver_m_00000000000603188840_1382872298_init()
{
	static char *pe[] = {(void *)Gate_29_0};
	xsi_register_didat("simprims_ver_m_00000000000603188840_1382872298", "isim/Single_Cycle_test_isim_par.exe.sim/simprims_ver/m_00000000000603188840_1382872298.didat");
	xsi_register_executes(pe);
}

extern void simprims_ver_m_00000000000603188840_1461969519_init()
{
	static char *pe[] = {(void *)Gate_29_0};
	xsi_register_didat("simprims_ver_m_00000000000603188840_1461969519", "isim/Single_Cycle_test_isim_par.exe.sim/simprims_ver/m_00000000000603188840_1461969519.didat");
	xsi_register_executes(pe);
}

extern void simprims_ver_m_00000000000603188840_3226743947_init()
{
	static char *pe[] = {(void *)Gate_29_0};
	xsi_register_didat("simprims_ver_m_00000000000603188840_3226743947", "isim/Single_Cycle_test_isim_par.exe.sim/simprims_ver/m_00000000000603188840_3226743947.didat");
	xsi_register_executes(pe);
}
